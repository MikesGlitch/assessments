import { useRoute } from 'vue-router'

export default function useBreadcrumbs() {
  //TODO: Add Breadcrumb logic here
  const route = useRoute()
  const bcHome = null
  const bcItems = null
  const bcTitle = null

  return { bcHome, bcItems, bcTitle }
}
