<template>
  <div class="w-90p ml-5p p-0 my-4 shadow-lg border-gray-100 border-2 h-full flex flex-col">
    <div class="flex bg-isogray-3 items-center h-10">
      <h1 class="ml-4 font-bold flex-1">{{ bcTitle }} - recordNumber</h1>
      <div class="icon-container bg-blue-400">
        <i class="pi pi-sitemap"></i>
      </div>
      <div class="icon-container bg-rouge cursor-pointer" @click="onClickClose()">
        <i class="pi pi-times"></i>
      </div>
    </div>
    <div>TODO: Add Input Form</div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import { useRouter } from 'vue-router'
import { IncidentType } from '@/typings/IncidentTypes'
import { StatusType } from '@/typings/StatusType'

import { useStoreRecords } from '@/store/storeRecords'
import { sections, statuses, impactOptions, eventOptions } from '@/data'

export default defineComponent({
  setup() {
    const router = useRouter()
    const records = useStoreRecords()
    //TODO Add form data logic

    const onClickClose = () => {
      //Close without saving
      router.push({ name: 'IncidentManagement' })
    }

    const onClickConfirm = () => {
      //Save and then close
      //TODO add save logic
      router.push({ name: 'IncidentManagement' })
    }

    return {
      onClickClose,
      sections,
      onClickConfirm,
      impactOptions,
      eventOptions,
      statuses,
    }
  },
})
</script>

<style scoped></style>
