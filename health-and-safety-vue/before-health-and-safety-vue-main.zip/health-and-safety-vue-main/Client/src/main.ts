import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import PrimeVue from 'primevue/config'
import { createPinia } from 'pinia'

//PrimeVue Components
import Button from 'primevue/button'
import Card from 'primevue/card'
//TODO Add required components

//Tailwind styles and PrimeVue themes
import './styles/index.css'

const app = createApp(App)
app.use(router)
app.use(PrimeVue)
app.use(createPinia())

//PrimeVue components
app.component('Button', Button)
app.component('Card', Card)
//TODO Add required components

app.mount('#app')
