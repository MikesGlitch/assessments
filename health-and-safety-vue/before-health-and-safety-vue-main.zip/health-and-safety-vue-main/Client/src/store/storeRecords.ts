import { defineStore } from 'pinia'
import axios from 'axios'
import { IncidentType } from '@/typings/IncidentTypes'

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

export const API = axios.create({
  baseURL: '',
})

export const useStoreRecords = defineStore({
  id: 'storeRecords',
  state: () => ({
    record: {} as IncidentType,
    records: [] as IncidentType[],
    isLoading: false,
  }),
  actions: {
    async addRecord(record: IncidentType) {
      //TODO: Add add record logic
    },

    async getRecords() {
      //TODO: Add get records logic
      await delay(2000) // Fake Delay (KEEP)
    },
  },
})
