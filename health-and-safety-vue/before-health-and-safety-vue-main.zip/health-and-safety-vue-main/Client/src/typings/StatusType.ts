export interface StatusType {
  id: number
  description: string
  colour: string
}
