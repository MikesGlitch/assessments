export interface TagType {
  id: number
  incidentTypeId: number
  name: string
}
export interface IncidentType {
  // TODO: Add type data
}
