export interface StoryType {
  id: number
  description: string
  title: string
}
