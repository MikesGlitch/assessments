<template>
  <div>TODO: Add Datatable</div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import Tags from '@/components/Tags.vue'
import Status from '@/components/Status.vue'
import dayjs from 'dayjs'

export default defineComponent({
  name: 'RecordsView',
  components: {},
  props: {
    items: {
      type: Array,
      required: true,
    },
    isLoading: {
      type: Boolean,
      required: true,
    },
  },
  setup() {
    //Date Formating logic
    const formatDate = (date: number) => {
      return dayjs.unix(date).format('DD/MM/YYYY')
    }

    //TODO: DataTable Buttons Logic

    //TODO: Modal Logic

    return {
      formatDate,
    }
  },
})
</script>

<style scoped></style>
