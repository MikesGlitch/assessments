module.exports = {
  tabWidth: 2,
  semi: false,
  singleQuote: true,
  trailingComma: 'es5',
  printWidth: 120,
  endOfLine: 'crlf',
}
