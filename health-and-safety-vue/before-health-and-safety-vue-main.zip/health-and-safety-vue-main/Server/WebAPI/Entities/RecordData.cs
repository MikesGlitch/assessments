﻿namespace WebAPI.Entities
{
    public class RecordData
    {
        public int Id { get; set; }
        public int ControlId { get; set; }
        public int RecordId { get; set; }
        
        public string Value { get; set; }
    }
}